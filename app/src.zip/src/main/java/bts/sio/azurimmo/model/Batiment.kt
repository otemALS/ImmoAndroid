package bts.sio.azurimmo.model

data class Batiment(
    val id: Int,
    val adresse: String?,
    val ville: String?
)
